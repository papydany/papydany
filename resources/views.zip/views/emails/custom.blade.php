<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale = 1.0">
	<title>Upload right</title>
</head>
<body>
<table>
    
    <tr>
      <td>
         <p>Good Day</p>
         
         <p>You are getting the message because you click on Result upload Right. 
please copy the code<b> {{ $body }} </b> and past on the text box to activate your account</p>
          
         <p>Regard.<br/>Unical Result Database Unit </p>
         </td>
        </tr>
         </table>
</body>
</html>